﻿namespace Schedule.Domain.Entities
{
    public enum MatchStatus
    {
        Scheduled,
        InProgress,
        Finished
    }
}

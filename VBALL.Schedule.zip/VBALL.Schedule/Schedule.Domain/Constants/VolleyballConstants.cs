﻿namespace Schedule.Domain.Constants
{
    public static class VolleyballConstants
    {
        public const int MaxPlayerPerTeam = 7;
    }
}

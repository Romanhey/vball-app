﻿using Schedule.Domain.Entities;

namespace Schedule.Application.DTO.Participation
{
    public record class UpdateParticipationDTO(ParticipationStatus Status);
}

﻿namespace Schedule.Application.DTO.Participation
{
    public record class CreateParticipationDTO(int MatchId, int PlayerId);
    
}

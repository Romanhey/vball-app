﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Schedule.Presentation.Controllers
{
    public class ParticipationController(IMediator mediator, IMapper mapper):ControllerBase
    {

    }
}

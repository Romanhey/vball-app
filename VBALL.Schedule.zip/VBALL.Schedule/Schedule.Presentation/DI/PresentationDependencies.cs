﻿namespace Schedule.Presentation.DI
{
    public class PresentationDependencies
    {
    }
}
